<?php
session_start();
require '../database/database.php';

// Redirect to login page if user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$pdo = Database::connect();
$sql = "SELECT c.id, c.short_comment, c.long_comment, c.posted_date, 
               p.fname, p.lname, i.short_description, i.project 
        FROM iss_comments c
        JOIN iss_persons p ON c.per_id = p.id
        JOIN iss_issues i ON c.iss_id = i.id
        ORDER BY c.posted_date DESC";
$comments = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
Database::disconnect();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Comments</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fa;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 1000px;
            margin: auto;
            padding: 20px;
            background-color: #ffffff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        .logout-btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 15px;
            text-decoration: none;
            color: white;
            background-color: #dc3545;
            border-radius: 5px;
        }
        .logout-btn:hover {
            opacity: 0.8;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>All Comments</h2>
        <a href="issues_list.php" class="logout-btn">Back to Issues</a>
        <table>
            <tr>
                <th>Comment ID</th>
                <th>Issue</th>
                <th>Project</th>
                <th>Comment By</th>
                <th>Short Comment</th>
                <th>Long Comment</th>
                <th>Posted Date</th>
            </tr>
            <?php foreach ($comments as $comment): ?>
                <tr>
                    <td><?= htmlspecialchars($comment['id']) ?></td>
                    <td><?= htmlspecialchars($comment['short_description']) ?></td>
                    <td><?= htmlspecialchars($comment['project']) ?></td>
                    <td><?= htmlspecialchars($comment['fname'] . ' ' . $comment['lname']) ?></td>
                    <td><?= htmlspecialchars($comment['short_comment']) ?></td>
                    <td><?= htmlspecialchars($comment['long_comment']) ?></td>
                    <td><?= htmlspecialchars($comment['posted_date']) ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>
</body>
</html>
