<?php
session_start();
require '../database/database.php';

// Redirect to login page if user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Get user details (admin status and user ID)
$pdo = Database::connect();
$stmt = $pdo->prepare("SELECT id, admin FROM iss_persons WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
Database::disconnect();

// Handle Delete
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $pdo = Database::connect();
    $delete_stmt = $pdo->prepare("DELETE FROM iss_persons WHERE id = ?");
    $delete_stmt->execute([$delete_id]);
    Database::disconnect();
    header("Location: persons_list.php");
    exit();
}

// Handle Update
if (isset($_POST['update_persons'])) {
    $id = $_POST['id'];
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $mobile = $_POST['mobile'];
    $email = $_POST['email'];

    $pdo = Database::connect();
    $update_stmt = $pdo->prepare("UPDATE iss_persons SET fname = ?, lname = ?, mobile = ?, email = ? WHERE id = ?");
    $update_stmt->execute([$fname, $lname, $mobile, $email, $id]);
    Database::disconnect();
    header("Location: persons_list.php");
    exit();
}

// Fetch Persons
$pdo = Database::connect();
$sql = "SELECT * FROM iss_persons ORDER BY id DESC";
$persons = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
Database::disconnect();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Persons List</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f7fa;
        }
        .container {
            max-width: 1000px;
            margin: auto;
            padding: 20px;
            background-color: #ffffff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px 21px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        td button {
            padding: 5px 10px;
            margin: 3px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        td button:hover {
            opacity: 0.8;
        }
        .view-btn {
            background-color: #007bff;
            color: white;
        }
        .update-btn {
            background-color: #ffc107;
            color: white;
        }
        .delete-btn {
            background-color: #dc3545;
            color: white;
        }
        .add-btn, .logout-btn, .back-btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 15px;
            text-decoration: none;
            color: white;
            background-color: #28a745;
            border-radius: 5px;
        }
        .back-btn {
            background-color:rgb(177, 61, 115);
        }
        .logout-btn {
            background-color: #dc3545;
        }
        .logout-btn:hover, .add-btn:hover {
            opacity: 0.8;
        }
        .persons-details, .update-form {
            margin-top: 20px;
            padding: 10px;
            background-color: #f9f9f9;
            border: 1px solid #ddd;
        }
        .update-form input, .update-form textarea {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .update-form button {
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .exit-btn {
            background-color: #6c757d;
            color: white;
            padding: 5px 10px;
            margin-top: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .exit-btn:hover {
            opacity: 0.8;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Persons List</h2>

                <!-- Add person & Logout Buttons -->
                <a href="register.php" class="add-btn">+ Add Person</a>
        <a href="issues_list.php" class="back-btn">Back to Issues</a>
        <a href="login.php" class="logout-btn">Logout</a>

        <!-- Read or Update Section (At the Top) -->
        <?php
        // Handle Read: Show details of the selected persons
        if (isset($_GET['read_id'])):
            $read_id = $_GET['read_id'];
            $pdo = Database::connect();
            $read_stmt = $pdo->prepare("SELECT * FROM iss_persons WHERE id = ?");
            $read_stmt->execute([$read_id]);
            $person_details = $read_stmt->fetch(PDO::FETCH_ASSOC); // Rename variable to avoid conflict
            Database::disconnect();
        ?>
            <div class="persons-details">
                <h3>Persons Details</h3>
                <p><strong>ID:</strong> <?= htmlspecialchars($person_details['id']) ?></p>
                <p><strong>First Name:</strong> <?= htmlspecialchars($person_details['fname']) ?></p>
                <p><strong>Last Name:</strong> <?= htmlspecialchars($person_details['lname']) ?></p>
                <p><strong>Mobile:</strong> <?= htmlspecialchars($person_details['mobile']) ?></p>
                <p><strong>Email:</strong> <?= htmlspecialchars($person_details['email']) ?></p>
                <p><strong>Admin:</strong> <?= htmlspecialchars($person_details['admin']) ?></p>
                <a href="persons_list.php" class="exit-btn">Exit View</a>
            </div>
        <?php endif; ?>

        <?php
        // Handle Update: Show the form to update the persons
        if (isset($_GET['update_id'])):
            $update_id = $_GET['update_id'];
            $pdo = Database::connect();
            $update_stmt = $pdo->prepare("SELECT * FROM iss_persons WHERE id = ?");
            $update_stmt->execute([$update_id]);
            $persons_to_update = $update_stmt->fetch(PDO::FETCH_ASSOC);
            Database::disconnect();
        ?>
            <div class="update-form">
                <h3>Update Persons</h3>
                <form method="post">
                    <input type="hidden" name="id" value="<?= $persons_to_update['id'] ?>">
                    <label for="fname">First Name:</label>
                    <input type="text" name="fname" value="<?= htmlspecialchars($persons_to_update['fname']) ?>" required>
                    <label for="lname">Last Name:</label>
                    <textarea name="lname" required><?= htmlspecialchars($persons_to_update['lname']) ?></textarea>
                    <label for="mobile">Mobile:</label>
                    <input type="text" name="mobile" value="<?= htmlspecialchars($persons_to_update['mobile']) ?>" required>
                    <label for="email">Email:</label>
                    <input type="text" name="email" value="<?= htmlspecialchars($persons_to_update['email']) ?>" required>
                    <button type="submit" name="update_persons">Update Persons</button>
                </form>
                <a href="persons_list.php" class="exit-btn">Exit Update</a>
            </div>
        <?php endif; ?>

        <!-- Persons Table -->
        <table>
            <tr>
                <th>ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Mobile</th>
                <th>Email</th>
                <th>Admin</th>
                <th>buttons</th>
            </tr>
            <?php foreach ($persons as $persons): ?>
                <tr>
                    <td><?= htmlspecialchars($persons['id']) ?></td>
                    <td><?= htmlspecialchars($persons['fname']) ?></td>
                    <td><?= htmlspecialchars($persons['lname']) ?></td>
                    <td><?= htmlspecialchars($persons['mobile']) ?></td>
                    <td><?= htmlspecialchars($persons['email']) ?></td>
                    <td><?= htmlspecialchars($persons['admin']) ?></td>
                    <td>
                        <!-- Read Button (always visible) -->
                        <a href="persons_list.php?read_id=<?= $persons['id'] ?>" ><button class="view-btn">R</button></a>

                        <?php
                        // Update and Delete buttons only visible if the user created the persons or is an admin
                        if ($user['admin'] == 'y' || $persons['id'] == $user['id']): ?>
                            <!-- Update Button -->
                            <a href="persons_list.php?update_id=<?= $persons['id'] ?>" ><button class="update-btn">U</button></a>
                            <!-- Delete Button -->
                            <a href="persons_list.php?delete_id=<?= $persons['id'] ?>" ><button class="delete-btn">D</button></a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
        

    </div>
</body>
</html>
